package com.teacherconnect.myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
